using UnityEngine;
using System.Collections;

public class FollowBehavior : MonoBehaviour
{
    private enum FollowBehaviorState { Moving = 0, Pausing = 1 }

    public Transform followTarget;
    public float followApproachDistance = 5.0f;
    public float followTriggerDistance = 10.0f;
    public float speed = 4.0f;
    public AnimationClip followApproachAnimation;
    public AnimationClip followIdleAnimation;

    private FollowBehaviorState followState;

    void Start()
    {
        followApproachAnimation.wrapMode = WrapMode.Loop;
        followIdleAnimation.wrapMode = WrapMode.Loop;

        followState = FollowBehaviorState.Moving;
        animation.Play(followApproachAnimation.name);
    }

    Vector3 GetDestination()
    {
        Vector3 destination = followTarget.position;
        destination.y = transform.position.y;
        return destination;
    }

    void Update()
    {
        if (followState == FollowBehaviorState.Moving)
        {
            if ((followTarget.position - transform.position).magnitude <= followApproachDistance)
            {
                followState = FollowBehaviorState.Pausing;
                animation.CrossFade(followIdleAnimation.name, 0.2f);
            }
            else
            {
                transform.forward = GetDestination() - transform.position;
                transform.Translate(Vector3.forward * speed * Time.deltaTime);
            }
        }
        else if (followState == FollowBehaviorState.Pausing)
        {
            float distance = (transform.position - GetDestination()).magnitude;
            if (distance > followTriggerDistance)
            {
                followState = FollowBehaviorState.Moving;
                animation.CrossFade(followApproachAnimation.name, 0.2f);
            }
        }
    }

    void LateUpdate()
    {
        transform.position = new Vector3(transform.position.x, Terrain.activeTerrain.SampleHeight(transform.position), transform.position.z);
    }
}