SPGSimpleAIBehaviors

This is a sample project for the Unity3d engine that shows a few simple AI behaviors.

Check out my website for more:

http://www.stevegargolinski.com
http://www.stevegargolinski.com/some-simple-ai-behaviors-in-unity/

Feel free to use the code in here as a basis for your own projects, the included assets are from
the Bootcamp Unity demo.